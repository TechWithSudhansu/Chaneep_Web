


<!-- Event snippet for Page view (1) conversion page In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. --> 

<script> function gtag_report_conversion(url) { var callback = function () { if (typeof(url) != 'undefined') { window.location = url; } }; gtag('event', 'conversion', { 'send_to': 'AW-16597121919/Zdq2CJCpibkZEP_2j-o9', 'event_callback': callback }); return false; } </script>





<!DOCTYPE html>

<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=utf-8" />


 
<head>

    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-EEGKBHKWV3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-EEGKBHKWV3');
</script>

    

    <!-- Meta Pixel Code -->

<script>

!function(f,b,e,v,n,t,s)

{if(f.fbq)return;n=f.fbq=function(){n.callMethod?

n.callMethod.apply(n,arguments):n.queue.push(arguments)};

if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';

n.queue=[];t=b.createElement(e);t.async=!0;

t.src=v;s=b.getElementsByTagName(e)[0];

s.parentNode.insertBefore(t,s)}(window, document,'script',

'https://connect.facebook.net/en_US/fbevents.js');

fbq('init', '984794403325698');

fbq('track', 'PageView');

</script>

<noscript><img height="1" width="1" style="display:none"

src="https://www.facebook.com/tr?id=984794403325698&ev=PageView&noscript=1"

/></noscript>

<!-- End Meta Pixel Code -->

    

    

    <!-- Meta Tags -->

   

    <link rel="icon" type="image/x-icon" href="img/favicon.png">

    <!-- Icon fonts -->

    <link href="assets/css/themify-icons.css" rel="stylesheet">

    <link href="assets/css/flaticon.css" rel="stylesheet">



    <!-- Bootstrap core CSS -->

    <link href="assets/css/bootstrap.min.css" rel="stylesheet">



    <!-- Plugins for this template -->

    <link href="assets/css/animate.css" rel="stylesheet">

    <link href="assets/css/owl.carousel.css" rel="stylesheet">

    <link href="assets/css/owl.theme.css" rel="stylesheet">

    <link href="assets/css/slick.css" rel="stylesheet">

    <link href="assets/css/slick-theme.css" rel="stylesheet">

    <link href="assets/css/owl.transitions.css" rel="stylesheet">

    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">

<script src='//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit'></script>

    <!-- Custom styles for this template -->

    <link href="assets/css/style.css" rel="stylesheet">



    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->

    <!--[if lt IE 9]>

    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>

    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

    <![endif]-->



<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous"> <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
        integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

	<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <meta name="author" content="swapdigit">



<!-- socalmidea lines meta tags -->

<meta name="twitter:title" content="web Development & Design">
<meta name="twitter:description" content="Twitter.">
<meta name="twitter:url" content="assets/images/slider/1.jpg">
<meta name="twitter:card" content="https://swapdigit.com/">



<meta name="you tube:title" content="web Development & Design">
<meta name="you tube:description" content="You Tube.">
<meta name="you tube:url" content="assets/images/slider/1.jpg">
<meta name="you tube:card" content="https://swapdigit.com/">



<meta name="Facebook:title" content="web Development & Design">
<meta name="Facebook:description" content="Facebook.">
<meta name="Facebook:url" content="assets/images/slider/1.jpg">
<meta name="Facebook:card" content="https://swapdigit.com/">




<meta name="instagram:title" content="web Development & Design">
<meta name="instagram:description" content="instagram.">
<meta name="instagram:url" content="assets/images/slider/1.jpg">
<meta name="instagram:card" content="https://swapdigit.com/">



<meta name="linkedin:title" content="web Development & Design">
<meta name="linkedin:description" content="linkedin.">
<meta name="linkedin:url" content="assets/images/slider/1.jpg">
<meta name="linkedin:card" content="https://swapdigit.com/">





</head>



<body>



    <!-- start page-wrapper -->

    <div class="page-wrapper">



        <!-- start preloader -->

        <!--<div class="preloader">-->

        <!--    <div class="spinner">-->

        <!--        <div class="double-bounce1"></div>-->

        <!--        <div class="double-bounce2"></div>-->

        <!--    </div>-->

        <!--</div>-->

        <!-- end preloader -->



        <!-- Start header -->

        <header id="header" class="site-header header-style-1">

            <div class="topbar">

                <div class="container">

                    <div class="row">

                        <div class="col col-sm-8">

                            <div class="contact-info">

                                <ul>

                                    <li><i class="ti-mobile"></i> <a style="color:white;" href="tel:+91-9412686863">+91-9412686863</a></li>

                                    <li><i class="ti-email"></i> <a style="color:white;" href="mailto:swapdigit@gmail.com">swapdigit@gmail.com</a></li>

                                    

                                    <li><i class="ti-location-pin"></i>Opp MJP Rohilkhand University Bareilly UP India</li>

                                </ul>

                            </div>

                        </div>

                        <div class="col col-sm-4">

                            <div class="social-quote">

                                <div class="social-links">

                                    <ul>

                                        <li><a href="https://www.facebook.com/swapdigit"><i class="ti-facebook"></i></a></li>

                                        <li><a href="https://twitter.com/swapdigit"><i class="ti-twitter-alt"></i></a></li>

                                        <li><a href="https://www.instagram.com/swapdigit/"><i class="ti-instagram"></i></a></li>

                                        <li><a href="https://www.youtube.com/@swapdigit"><i class="ti-youtube"></i></a></li>

                                        <li><a href="https://www.linkedin.com/company/swapdigit/"><i class="ti-linkedin"></i></a></li>

                                    </ul>

                                </div>

                                <!--<div class="quote">-->

                                <!--    <a href="#">Free consultation</a>-->

                                <!--</div>-->

                            </div>

                        </div>

                    </div>

                </div> <!-- end container -->

            </div>

            <!-- end topbar -->



            <nav class="navigation navbar navbar-default">

                <div class="container">

                    <div class="navbar-header">

                        <button type="button" class="open-btn">

                            <span class="sr-only">Toggle navigation</span>

                            <span class="icon-bar"></span>

                            <span class="icon-bar"></span>

                            <span class="icon-bar"></span>

                        </button>

                        <a class="navbar-brand" href="index"><img  src="img/logo.png" alt="Logo"></a>

                    </div>

                    <div id="navbar" class="navbar-collapse collapse navbar-right navigation-holder">

                        <button class="close-navbar"><i class="ti-close"></i></button>

                        <ul class="nav navbar-nav">

                            <li>

                                <a href="index">Home</a>

                               

                            </li>

                            <li class="menu-item-has-children">

<a href="#">About</a>

<ul class="sub-menu">

<li><a href="about">About Us</a></li>

<li><a href="our-team">Our Team</a></li>

<li><a href="technology">Technology</a></li> 

<!-- <li><a href="technology">Hire Developers</a></li> -->
                                </ul>

                            </li>

                            <!--<li>-->

                            <!--    <a href="about">MLM Software</a>-->

                            <!--</li>-->

                            <li class="menu-item-has-children">

                                <a href="#">Services</a>

                                <ul class="sub-menu">

                                    <li><a href="software-development-in-india">Software Development</a></li>

                                    <li><a href="website-development-in-india">Website Development</a></li>

                                    <li><a href="mobileapp-development-in-india">Mobile App Development</a></li>

                                    <li><a href="digital-marketing-in-india">Digital Marketing</a></li>

                                    <li><a href="e-commerce-in-india">E-Commerce Solution</a></li>

                                    <li><a href="seo-sem-in-india">SEO & SEM</a></li>

                                    <li><a href="mlm-software-in-india">MLM Software</a></li>

                                </ul>

                            </li>

                            

                            <li class="menu-item-has-children">

                                <a href="#">Courses & Training</a>

                                <ul class="sub-menu">

                                    <li><a href="live-project-training-in-bareilly">Live Project Training</a></li>

                                    <li><a href="summer-training-in-bareilly">Summer Training</a></li>

                                    <li><a href="industrial-training-in-bareilly">Industrial Training</a></li>

                                    <li><a href="live-project-in-bareilly">Live Project</a></li>

                                     <li><a href="php-course-training-in-bareilly">PHP  Training</a></li>

                                      <li><a href="asp.net-course-training-in-bareilly">Asp.Net  Training</a></li>

                                       <li><a href="java-course-training-in-bareilly">Java  Training</a></li>

                                        <li><a href="nodejs-course-training-in-bareilly">Nodejs  Training</a></li>

                                         <li><a href="datascience-course-training-in-bareilly">Data Science  Training</a></li>

                                          <li><a href="python-course-in-bareilly">Python Training</a></li>

                                           <li><a href="machine-learning-course-training-in-bareilly">Machine Learning/AI Training</a></li>

                                            <li><a href="web-designing-course-training-in-bareilly">Web Designing Training</a></li>

                                            <li><a href="web-development-course-training-in-bareilly">Web Development Training</a></li>

                                    

                                </ul>

                            </li>

                            

                             <li class="menu-item-has-children">

                                <a href="#">Industries</a>

                                <ul class="sub-menu">

                                    <li><a href="health-industries">Health Industries</a></li>

                                    <li><a href="education-industries">Education  Industries</a></li>

                                    <li><a href="financial-industries">Financial  Industries</a></li>

                                    <li><a href="e-commerce-industries">E-commerce Industries</a></li>

                                    <li><a href="automobile-industries">Automobile Industries</a></li>

                                     <li><a href="agriculture-industries">Agriculture Industries</a></li>

                                     <li><a href="manufacturing-industries"> Manufacturing Industries</a></li>

                                  
                                    

                                </ul>

                            </li>

                              

                             <li><a href="#">Product
                             </a></li>

                             <!-- .......hire developers....... -->

                             <!-- <li class="menu-item-has-children">

<a href="#"></a>

<ul class="sub-menu">

    <li><a href="hire-a-html-developer.php">Hire HTML developer</a></li>

    <li><a href=""></a></li>

    <li><a href=""></a></li>

    <li><a href=""></a></li>

    <li><a href=""></a></li>

    <li><a href=""></a></li>

    <li><a href=""></a></li>

</ul>

</li> -->









                             <li><a href="contact">Contact</a></li>

<!--                           <li style="-->

<!--    margin-top: 29px;-->

<!--"><form><script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_NOqStBvSIHJPn6" async> </script> </form></li>-->

                           

                        </ul>

                    </div><!-- end of nav-collapse -->

                    <div class="navigation-search-area">

                        <div class="header-search-area">

                            <!--<div class="header-search-form">-->

                            <!--    <form class="form">-->

                            <!--        <div>-->

                            <!--            <input type="text" class="form-control" placeholder="Search here">-->

                            <!--        </div>-->

                            <!--        <button type="submit" class="btn"><i class="fi flaticon-magnifying-glass-browser"></i></button>-->

                            <!--    </form>-->

                            <!--</div>-->

                            <!--<div>-->

                            <!--    <button class="btn open-btn"><i class="fi flaticon-magnifying-glass-browser"></i></button>-->

                            <!--</div>-->

                        </div>

                    </div>

                </div><!-- end of container -->

            </nav>

        </header>

        <!-- end of header -->

<div class="grid">

<div class="entry-media hover22">

<a href="seo-sem-in-india">

<figure>

<img src="assets/images/icon/angular3d.jpg" alt="angular js">

</figure>

</a>

</div>



</div>
<style>

    .social{

        color:white;

    }

</style>





 <!-- start site-footer -->

        <footer class="site-footer">

            <div class="upper-footer">

                <div class="container">

<div class="row">
<div class="col col-lg-3 col-md-3 col-sm-12">
                <div class="logo widget-title">

                                    <img style="background-color:white;border-radius:100%;" src="img/logo.png" alt="Logo" hight="230px" width="200px">
                                  
</div>

</div>
<div class="col col-lg-9 col-md-9 col-sm-12">
<p >SwapDigit, aims to provide high quality Software Development, Website Development, Apps Development, Digital Marketing, IT infrastructure Support & Services, <a class=social href="about">Readmore...</a> </p>
</div>       
</div>
                                


                    <div class="row">

                        <div class="col col-lg-3 col-md-3 col-sm-6">

                            <div class="widget about-widget">

                                <!-- <div class="logo widget-title"> -->

                                    <!-- <img style="background-color:white;border-radius:100%;" src="img/logo.png" alt="Logo"> -->

                                <!-- </div> -->

                                <!-- <p>SwapDigit, aims to provide high quality Software Development, Website Development, Apps Development, Digital Marketing, IT infrastructure Support & Services, <a class=social href="about">Readmore...</a> </p> -->

                                

                                 <div class="widget-title">

                                    <h3>Contact Us</h3>

                                </div>

                                

                                 <ul >

                                     

                                    <!--<li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="contact">Contact Us</a></li>-->

                                    

                                      <li style="margin-bottom:15px;"><i class="ti-location-pin fa-shake"></i>&nbsp;<a href="#"></a>&nbsp;&nbsp;Opp MJP Rohilkhand University Bareilly UP India - 243006</li>
          
                                 
                                     <li style="margin-bottom:15px;"><i class="ti-mobile fa-shake"></i>&nbsp;<a style="color:white;" href="tel:+91-9412686863">+91-9412686863</a></li>

                                     

                                     <li><i class="ti-email fa-shake"></i>&nbsp; <a style="color:white;" href="mailto:swapdigit@gmail.com">swapdigit@gmail.com</a></li>

                                </ul>

                                

                                <!-- <ul style="display:flex;margin-top:15px;">

                                        <li></li>

                                        <li style="font-size: 20px;"><a class=social href="https://www.facebook.com/swapdigit"><i class="ti-facebook"></i></a></li>&nbsp;&nbsp;

                                        <li style="font-size: 20px;"><a class=social href="https://twitter.com/swapdigit"><i class="ti-twitter-alt"></i></a></li>&nbsp;&nbsp;

                                        <li style="font-size: 20px;"><a class=social href="https://www.instagram.com/swapdigit/"><i class="ti-instagram"></i></a></li>&nbsp;&nbsp;

                                        <li style="font-size: 20px;"><a class=social href="https://www.youtube.com/@swapdigit"><i class="ti-youtube"></i></a></li>&nbsp;&nbsp;

                                        <li style="font-size: 20px;"><a class=social href="https://www.linkedin.com/company/swapdigit/"><i class="ti-linkedin"></i></a></li>

                                    </ul>

                              <ul style="display:flex;margin-top:15px;">       

<form><script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_NOqStBvSIHJPn6" async> </script> </form>  </ul> -->

<br><br>
    
<div class="footer-pay">
 

                                    
 <ul style="display:flex;">
 
 <li></li>
 
 <li style="font-size: 20px;"><a class=social href="https://www.facebook.com/swapdigit"><i class="ti-facebook"></i></a></li>&nbsp;&nbsp;
 
 <li style="font-size: 20px;"><a class=social href="https://twitter.com/swapdigit"><i class="ti-twitter-alt"></i></a></li>&nbsp;&nbsp;
 
 <li style="font-size: 20px;"><a class=social href="https://www.instagram.com/swapdigit/"><i class="ti-instagram"></i></a></li>&nbsp;&nbsp;
 
 <li style="font-size: 20px;"><a class=social href="https://www.youtube.com/@swapdigit"><i class="ti-youtube"></i></a></li>&nbsp;&nbsp;
 
 <li style="font-size: 20px;"><a class=social href="https://www.linkedin.com/company/swapdigit/"><i class="ti-linkedin"></i></a></li>
 
 </ul>
 
 <!-- <ul style="display:flex; margine:10px;">        -->
    
    </div>
 <!-- </ul> -->
 

                            </div>

                        </div>

                        <div class="col col-lg-3 col-md-3 col-sm-6">

                            <div class="widget link-widget">

                                <div class="widget-title">

                                    <h3>Services</h3>

                                </div>

                                <ul class="sub-menu">

                                  <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="software-development-in-india">Software Development</a></li>

                                    <li> <i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="website-development-in-india">Website Development</a></li>

                                    <li> <i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="mobileapp-development-in-india">Mobile App Development</a></li>

                                    <li> <i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="digital-marketing-in-india">Digital Marketing</a></li>

                                    <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="e-commerce-in-india">E-Commerce Solution</a></li>

                                    <li> <i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="seo-sem-in-india">SEO & SEM</a></li>

                                    <li> <i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="mlm-software-in-india">MLM Software</a></li>

                                </ul>

                            </div>

                        </div>

                        <div class="col col-lg-3 col-md-3 col-sm-6">

                            <div class="widget link-widget">

                                <div class="widget-title">

                                    <h3>Courses & Training</h3>

                                </div>

                               <ul >

                                     <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="live-project-training-in-bareilly">Live Project Training</a></li>

                                    <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="summer-training-in-bareilly">Summer Training</a></li>

                                    <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="industrial-training-in-bareilly">Industrial Training</a></li>

                                    <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="live-project-in-bareilly">Live Project</a></li>
                                    

                                    <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="php-course-training-in-bareilly">PHP  Training</a></li>

                                    <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="asp.net-course-training-in-bareilly.php">Asp.Net  Training</a></li>

                                    <li><i class="fas fa-arrow-right" style="color:#fea815"></i><a href="java-course-training-in-bareilly">Java  Training</a></li>

                                <!--     <div class="widget-title">-->

                                <!--    <h3>Terms & Conditions</h3>-->

                                <!--</div>-->

                                <!--    <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="terms-&-conditions">Terms & Conditions</a></li>-->

                                <!--    <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="privacy-policy">Privacy Policy</a></li>-->

                                <!--    <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="refund-&-cancellation">Refund & Cancellation</a></li>-->

                                <!--     <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="disclaimer">Disclaimer</a></li>-->

                                    

                                <!--</ul>-->

                            </div>

                        </div>

                        <div class="col col-lg-3 col-md-3 col-sm-6">

                            <div class="widget link-widget">

                                <div class="widget-title">

                                   <h3>Our Policy</h3>

                                </div>

                                

                                <!-- <ul >-->

                                     

                                <!--    <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="contact">Contact Us</a></li>-->

                                    

                                <!--      <li><i class="ti-location-pin"></i><a href="#">Address</a>&nbsp;&nbsp;Opp MJP Rohilkhand University Bareilly UP India - 243006</li>-->

                                    

                                <!--     <li><i class="ti-mobile"></i>&nbsp;<a style="color:white;" href="tel:+91-9412686863">+91-9412686863</a></li>-->

                                <!--</ul>-->

                                <ul>

                                      <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="disclaimer">Disclaimer</a></li>

                                       <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="privacy-policy">Privacy Policy</a></li>

                                 <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="terms-conditions">Terms & Conditions</a></li>

                                   

                                    <li><i class="fas fa-arrow-right" style="color:#fea815"></i> <a href="refund-cancellation">Refund & Cancellation</a></li>


                                    

                                </ul>

                                <br>

                                <!-- <form><script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_NOqStBvSIHJPn6" async> </script> </form>  -->
                               
<!-- <h3>Our Socalmidea lines</h3> -->
                                   
<!-- <a href="#"><img src="assets/images/phone-pay.png" alt="phone-pay" width="60px;" height="55px;" ></a> -->
 <div class="footer-span">
 <span>GSTIN: 09AFIFS2734L1ZI</span><br>
 <span>LLPIN: ACH-7098</span>
 </div>
   <!-- <a href="#"><img src="assets/images/g-pay.png" alt="G-pay" width="45px;" height="51px;"></a> -->
   
<form><script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_NOqStBvSIHJPn6" async> </script> </form> 
    <!-- <div class="footer-pay">
 

                                    
<ul style="display:flex;">

<li></li>

<li style="font-size: 20px;"><a class=social href="https://www.facebook.com/swapdigit"><i class="ti-facebook"></i></a></li>&nbsp;&nbsp;

<li style="font-size: 20px;"><a class=social href="https://twitter.com/swapdigit"><i class="ti-twitter-alt"></i></a></li>&nbsp;&nbsp;

<li style="font-size: 20px;"><a class=social href="https://www.instagram.com/swapdigit/"><i class="ti-instagram"></i></a></li>&nbsp;&nbsp;

<li style="font-size: 20px;"><a class=social href="https://www.youtube.com/@swapdigit"><i class="ti-youtube"></i></a></li>&nbsp;&nbsp;

<li style="font-size: 20px;"><a class=social href="https://www.linkedin.com/company/swapdigit/"><i class="ti-linkedin"></i></a></li>

</ul> -->

<!-- <ul style="display:flex; margine:10px;">        -->
   
   </div>
<!-- </ul> -->
                    

  <!--                              <div class="form">-->

                                    

  <!--                                 <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fswapdigit%2F&amp;tabs=timeline&amp;width=340&amp;height=500&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId" width="100%" height="160px" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>-->

			

		<!--</div>-->

<!--		<div  style="background: none;-->

<!--    background-color: #111b21;-->

<!--    border-radius: 50px;-->

<!--    font-size: 16px;-->

<!--    padding: 16px 28px;"-->

    



<!--		<div id='google_translate_element'></div>-->

<!--		</div>-->

                                </div>

                            </div>

                        </div>

                    </div>

                </div> <!-- end container -->

            </div>

            <!--<hr>-->
            
            <!-- <div class="whatsapp-blink">
    <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="WhatsApp" style="width: 24px; height: 24px;">
</div> -->

<div class="socal-media-icon">
    <div class="whatsapp-icon">
        <a  href="https://api.whatsapp.com/send?phone=91-9412686863&text=Hey%20Swapdigit"> <i class="fa-brands fa-whatsapp fa-beat" style="color:rgb(255, 255, 255);"></i></a>
    <!-- <i class="fa-brands fa-whatsapp fa-beat" style="color:rgb(255, 255, 255);"></i> -->
    </div>
    <div class="call-icon fa-beat">
    <a href="tel:+919412686863"><i class="fa-solid fa-phone  "style="color:rgb(255, 255, 255) ;"></i></a>
    </div>
</div>




            <div class="lower-footer">

                <div class="container">

                    <div class="row">

                        <div class="separator"></div>

<div class="col col-md-12 col-lg-12 ">
    

<p class="copyright">© 2018 Copyright. All rights reserved | SwapDigit LLP</p>



</div>
                    </div>

                </div>

            </div>

        </footer>

        <!-- end site-footer -->

    </div>

    <!-- end of page-wrapper -->

    <!-- All JavaScript files

    ================================================== -->

    <script src="assets/js/jquery.min.js"></script>

    <script src="assets/js/bootstrap.min.js"></script>



    <!-- Plugins for this template -->

    <script src="assets/js/jquery-plugin-collection.js"></script>



    <!-- Custom script for this template -->

    <script src="assets/js/script.js"></script>

</body>



<!-- Mirrored from ruhul440.github.io/html/confin/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 17 May 2023 07:56:48 GMT -->

</html>

<script type="text/javascript">

    // (function () {

    //     var options = {

    //         whatsapp: "+91-9412686863", // WhatsApp number

    //         call_to_action: "Message us", // Call to action

    //         position: "left", // Position may be 'right' or 'left'

    //     };

        var proto = document.location.protocol, host = "getbutton.io", url = proto + "//static." + host;

        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';

        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };



        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
        

    })();

</script>

 </style>



 



  <script>

 function googleTranslateElementInit() {

 new google.translate.TranslateElement({

 pageLanguage: 'en',

 autoDisplay: 'true',

 layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL

 }, 'google_translate_element');

 }

 </script>

 

 <!-- Google tag (gtag.js) -->

<script async src="https://www.googletagmanager.com/gtag/js?id=AW-16597121919">

</script>

<script>

  window.dataLayer = window.dataLayer || [];

  function gtag(){dataLayer.push(arguments);}

  gtag('js', new Date());



  gtag('config', 'AW-16597121919');

</script>









<!-- Event snippet for Page view (1) conversion page

In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. -->

<script>

function gtag_report_conversion(url) {

  var callback = function () {

    if (typeof(url) != 'undefined') {

      window.location = url;

    }

  };

  gtag('event', 'conversion', {

      'send_to': 'AW-16597121919/Zdq2CJCpibkZEP_2j-o9',

      'event_callback': callback

  });

  return false;

}

</script>